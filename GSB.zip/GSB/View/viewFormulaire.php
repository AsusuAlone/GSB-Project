<!DOCTYPE html>
<?php
//include 'Controller/classPDO.Gsb.inc.php';
include 'View/Accueil.php';
///include 'View/viewBandeau.php';
?>
