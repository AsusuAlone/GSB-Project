<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Accueil GSB</title>
        <link rel="stylesheet" href="View/accueil.css">
    </head>
    
    <body>
        <img src="GSB.jpg" alt="">
        <div class="container">
            <header class="header item"><h1>Bienvenue cheres visiteurs !</h1></header>
            <div class="flexbody">
                    <nav class="menuLeft item">Menu</nav>
                    <section class="content item"><p><a href="View/viewFormulaire.php">Veuillez trouver ci-joint le Formulaire</a></p></section>
            </div>
            <footer class="footer item">Footer</footer>
        </div>
    </body>
</html>



        