<?php
    $action = $_REQUEST['action'];
	$pdo = PdoGsb::getPdoGsb();
    switch($action){
        case 'AfficheResultat' :
            {
                $lesNumeros = $pdo-> getLesNumeros();
                include "View/formulaire.php";
                
                $lesTypesDeFrais = $pdo-> getLesTypesDeFrais();
                include "View/formulaire.php";
            }
    }

?>