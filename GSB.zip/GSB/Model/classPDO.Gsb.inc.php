<?php
class PdoGsb
{   		
      	private static $serveur='mysql:host=localhost';
      	private static $bdd='gsb_missionb';  		
      	private static $user='root';
      	private static $mdp='' ;
    /**
     * @var PDO $monPdo
     */
		private static $monPdo;
		private static $monPdoGsb = null;
/**
 * Constructeur privé, crée l'instance de PDO qui sera sollicitée
 * pour toutes les méthodes de la classe
 */				
	private function __construct()
	{
    		PdoGsb::$monPdo = new PDO(PdoGsb::$serveur.';'.PdoGsb::$bdd, PdoGsb::$user, PdoGsb::$mdp); 
			PdoGsb::$monPdo->query("SET CHARACTER SET utf8");
	}
	public function _destruct(){
		PdoGsb::$monPdo = null;
	}
/**
 * Fonction statique qui crée l'unique instance de la classe
 *
 * Appel : $instancePdoGsb = PdoGsb::getPdoGsb();
 * @return l'unique objet de la classe PdoGsb
 */
	public  static function getPdoGsb()
	{
		if(PdoGsb::$monPdoGsb == null)
		{
			PdoGsb::$monPdoGsb= new PdoGsb();
		}
		return PdoGsb::$monPdoGsb;  
	}
	public function getLesNumeros()
	{
		$req = "SELECT CONCAT(id, ' ', nom, ' ', prenom) AS 'Identifiant' FROM `visiteur`";
		$res = PdoGsb::$monPdo->query($req);
		$lesLignes = $res->fetchAll();
		return $lesLignes;
	}
	public function getLesTypesDeFrais()
	{
		$req = "select id from fraisforfait";
		$res = PdoGsb::$monPdo->query($req);
		$lesLignes = $res->fetchAll();
		return $lesLignes;
	}
}
?>