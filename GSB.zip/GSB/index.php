<?php
session_start();
include 'Model/classPDO.Gsb.inc.php';
include 'View/Accueil.php';
//include'vues/viewEntete.php' ;
$pdo = PdoGsb::getPdoGsb();
if(!isset($_REQUEST['uc']))
     $uc = 'Controller';
else
	$uc = $_REQUEST['uc'];
 
switch($uc)
{	
	case 'Accueil' :
		{include'View/Accueil.php';break;}

	case 'voirFormulaire' :
		{include'View/viewFormulaire.php';break;}
}
?>